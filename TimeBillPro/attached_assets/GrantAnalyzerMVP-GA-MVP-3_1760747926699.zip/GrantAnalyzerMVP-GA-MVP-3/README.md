# Property Elevation Analyzer

Analyze properties for elevation projects with data from Zillow and FEMA flood maps.

## Deployment on Netlify

This project is configured to deploy automatically to Netlify.

### Environment Variables

Add this environment variable in your Netlify dashboard:

- `RAPIDAPI_KEY` - Your RapidAPI key for Zillow data

To add it:
1. Go to Netlify Dashboard
2. Click on your site
3. Go to Site settings > Environment variables
4. Add `RAPIDAPI_KEY` with your API key

### How It Works

- **Netlify Functions**: Serverless functions handle API calls to Zillow and FEMA
- **Static Frontend**: React app deployed to Netlify CDN
- **No Database Required**: Results are displayed directly without persistence

## Local Development

```bash
npm install
npm run dev
```

## API Setup

See [API_SETUP_GUIDE.md](./API_SETUP_GUIDE.md) for detailed instructions on obtaining a RapidAPI key for Zillow data.
