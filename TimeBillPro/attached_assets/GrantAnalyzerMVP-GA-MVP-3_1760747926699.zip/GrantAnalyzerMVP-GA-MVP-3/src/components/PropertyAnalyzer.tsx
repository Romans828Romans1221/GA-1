import { useState } from 'react';
import { Search, MapPin, AlertCircle } from 'lucide-react';
import { scrapeZillowData, scrapeFloodData, getUSGSElevation, geocodeAddress } from '../services/scraperService';
import { PropertyReport } from '../types/property';

/**
 * PropertyAnalyzer Component
 *
 * Main component for analyzing properties for elevation projects
 * Allows users to input address and coordinates, then scrapes data from:
 * - Zillow: Property square footage and cost
 * - LSU AgCenter: Base flood elevation and flood zone
 */
export default function PropertyAnalyzer() {
  // Form input state
  const [address, setAddress] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [manualMode, setManualMode] = useState(false);

  // Manual input fields
  const [squareFootage, setSquareFootage] = useState('');
  const [propertyCost, setPropertyCost] = useState('');
  const [baseFloodElevation, setBaseFloodElevation] = useState('');
  const [floodZone, setFloodZone] = useState('');
  const [groundElevation, setGroundElevation] = useState('');

  // UI state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState<PropertyReport | null>(null);

  /**
   * Handles form submission and initiates data fetching
   * 1. Validates input fields
   * 2. Geocodes address if coordinates missing
   * 3. Fetches data from Zillow, FEMA, and USGS APIs
   * 4. Displays results to user
   */
  const handleAnalyze = async () => {
    console.log('🔵 Button clicked - Starting analysis');
    console.log('🚀 === STARTING PROPERTY ANALYSIS ===');
    console.log('Timestamp:', new Date().toISOString());

    // Reset error and report state
    setError(null);
    setReport(null);

    // Validate required fields
    if (!address.trim()) {
      setError('Please enter a property address');
      return;
    }

    let lat = parseFloat(latitude);
    let lng = parseFloat(longitude);

    // If coordinates are missing, try to geocode the address
    if (!latitude.trim() || !longitude.trim() || isNaN(lat) || isNaN(lng)) {
      console.log('⚠️ Coordinates missing - attempting geocoding');
      setLoading(true);

      const geocodeResult = await geocodeAddress(address);

      if (geocodeResult) {
        lat = geocodeResult.latitude;
        lng = geocodeResult.longitude;
        setLatitude(lat.toString());
        setLongitude(lng.toString());
        console.log('✅ Geocoded coordinates:', lat, lng);
        console.log('Matched address:', geocodeResult.matched_address);
      } else {
        setLoading(false);
        setError('Could not geocode address. Please enter coordinates manually.');
        return;
      }
    }

    if (lat < -90 || lat > 90) {
      setError('Latitude must be between -90 and 90');
      return;
    }

    if (lng < -180 || lng > 180) {
      setError('Longitude must be between -180 and 180');
      return;
    }

    setLoading(true);

    try {
      console.log('Starting property analysis...');

      let propertyReport: PropertyReport;

      if (manualMode) {
        propertyReport = {
          address,
          latitude: lat,
          longitude: lng,
          square_footage: squareFootage ? parseFloat(squareFootage) : null,
          property_cost: propertyCost ? parseFloat(propertyCost) : null,
          base_flood_elevation: baseFloodElevation ? parseFloat(baseFloodElevation) : null,
          flood_zone: floodZone || null,
          ground_elevation: groundElevation ? parseFloat(groundElevation) : null,
          created_at: new Date().toISOString(),
        };
      } else {
        console.log('📡 Calling all APIs in parallel...');
        const [zillowData, floodData, elevationData] = await Promise.all([
          scrapeZillowData(address),
          scrapeFloodData(lat, lng),
          getUSGSElevation(lat, lng),
        ]);

        console.log('📊 All API results:');
        console.log('Zillow data:', zillowData);
        console.log('FEMA Flood data:', floodData);
        console.log('USGS Elevation data:', elevationData);

        // Show helpful messages if data not available
        if (!zillowData.square_footage && !zillowData.property_cost) {
          console.log('ℹ️ Zillow data not available for this address');
        }

        if (!floodData.flood_zone && !floodData.base_flood_elevation) {
          console.log('ℹ️ FEMA flood data not available for this location');
        }

        if (!elevationData.ground_elevation) {
          console.log('ℹ️ USGS elevation data not available for this location');
        }

        propertyReport = {
          address,
          latitude: lat,
          longitude: lng,
          square_footage: zillowData.square_footage,
          property_cost: zillowData.property_cost,
          base_flood_elevation: floodData.base_flood_elevation,
          flood_zone: floodData.flood_zone,
          ground_elevation: elevationData.ground_elevation,
          created_at: new Date().toISOString(),
        };
      }

      console.log('✅ === ANALYSIS COMPLETE ===');

      console.log('Report generated successfully:', propertyReport);
      console.log('🏠 Zillow values in report:', {
        square_footage: propertyReport.square_footage,
        property_cost: propertyReport.property_cost
      });

      setReport(propertyReport);
    } catch (err) {
      console.error('Error analyzing property:', err);
      setError(
        err instanceof Error ? err.message : 'Failed to analyze property'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-slate-800 mb-3">
            Property Elevation Analyzer
          </h1>
          <p className="text-slate-600 text-lg">
            Analyze properties for elevation projects with data from Zillow and LSU AgCenter flood maps
          </p>
        </div>

        {/* Input Form Card */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-semibold text-slate-800">
              Property Information
            </h2>
            <button
              onClick={() => setManualMode(!manualMode)}
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              {manualMode ? 'Switch to Auto Mode' : 'Switch to Manual Entry'}
            </button>
          </div>

          {/* Address Input */}
          <div className="mb-6">
            <label
              htmlFor="address"
              className="block text-sm font-medium text-slate-700 mb-2"
            >
              Property Address
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input
                id="address"
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="123 Main St, City, ST 12345"
                className="w-full pl-11 pr-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Format: Street Number, Street Name, City, State ZIP (e.g., 111161 Natchez Dr, College Station, TX 77845)
            </p>
          </div>

          {/* Coordinates Input */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label
                htmlFor="latitude"
                className="block text-sm font-medium text-slate-700 mb-2"
              >
                Latitude
              </label>
              <input
                id="latitude"
                type="text"
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                placeholder="e.g., 30.4515"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>

            <div>
              <label
                htmlFor="longitude"
                className="block text-sm font-medium text-slate-700 mb-2"
              >
                Longitude
              </label>
              <input
                id="longitude"
                type="text"
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                placeholder="e.g., -91.1871"
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
              />
            </div>
          </div>

          {/* Manual Entry Fields */}
          {manualMode && (
            <div className="mb-6 p-6 bg-blue-50 border border-blue-200 rounded-lg">
              <h3 className="text-lg font-medium text-slate-800 mb-4">Manual Data Entry</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Square Footage
                  </label>
                  <input
                    type="number"
                    value={squareFootage}
                    onChange={(e) => setSquareFootage(e.target.value)}
                    placeholder="e.g., 2500"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Property Cost ($)
                  </label>
                  <input
                    type="number"
                    value={propertyCost}
                    onChange={(e) => setPropertyCost(e.target.value)}
                    placeholder="e.g., 350000"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Base Flood Elevation (ft)
                  </label>
                  <input
                    type="number"
                    value={baseFloodElevation}
                    onChange={(e) => setBaseFloodElevation(e.target.value)}
                    placeholder="e.g., 12.5"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Flood Zone
                  </label>
                  <input
                    type="text"
                    value={floodZone}
                    onChange={(e) => setFloodZone(e.target.value)}
                    placeholder="e.g., AE"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Ground Elevation (ft)
                  </label>
                  <input
                    type="number"
                    value={groundElevation}
                    onChange={(e) => setGroundElevation(e.target.value)}
                    placeholder="e.g., 45.2"
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-red-800 text-sm">{error}</p>
            </div>
          )}

          {/* Analyze Button */}
          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                Analyzing Property...
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                Analyze Property
              </>
            )}
          </button>
        </div>

        {/* Report Display */}
        {report && (
          <div className="bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-2xl font-semibold text-slate-800 mb-6">
              Property Analysis Report
            </h2>

            {/* Address Display */}
            <div className="mb-8 p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Address</p>
              <p className="text-lg font-medium text-slate-800">{report.address}</p>
              <p className="text-sm text-slate-500 mt-1">
                Coordinates: {report.latitude}, {report.longitude}
              </p>
            </div>

            {/* Data Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Zillow Data Section */}
              <div className="border border-slate-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-600 rounded-full" />
                  Zillow Data
                </h3>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Square Footage</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {report.square_footage
                        ? `${report.square_footage.toLocaleString()} sq ft`
                        : 'Not available'}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-slate-600 mb-1">Property Cost</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {report.property_cost
                        ? `$${report.property_cost.toLocaleString()}`
                        : 'Not available'}
                    </p>
                  </div>
                </div>
              </div>

              {/* FEMA Flood Data Section */}
              <div className="border border-slate-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <div className="w-2 h-2 bg-emerald-600 rounded-full" />
                  FEMA Flood Data
                </h3>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Base Flood Elevation (BFE)</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {report.base_flood_elevation
                        ? `${report.base_flood_elevation} ft`
                        : 'Not in SFHA'}
                    </p>
                  </div>

                  <div>
                    <p className="text-sm text-slate-600 mb-1">Flood Zone</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {report.flood_zone || 'Not available'}
                    </p>
                  </div>
                </div>
              </div>

              {/* USGS Elevation Data Section */}
              <div className="border border-slate-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-600 rounded-full" />
                  USGS Ground Elevation
                </h3>

                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Ground Elevation</p>
                    <p className="text-2xl font-bold text-slate-800">
                      {report.ground_elevation
                        ? `${report.ground_elevation} ft`
                        : 'Not available'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Info Messages */}
            {(!report.square_footage && !report.property_cost) && (
              <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-medium mb-1">Zillow data not available</p>
                  <p>This address may not be in Zillow's database. Try verifying the address format or use a different property address.</p>
                </div>
              </div>
            )}

            {(!report.flood_zone && !report.base_flood_elevation) && (
              <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">FEMA flood data not available</p>
                  <p>This location may not be in a designated flood zone or outside FEMA's coverage area. Verify the coordinates are correct.</p>
                </div>
              </div>
            )}

            {/* Timestamp */}
            {report.created_at && (
              <div className="mt-6 pt-6 border-t border-slate-200">
                <p className="text-sm text-slate-500">
                  Report generated on {new Date(report.created_at).toLocaleString()}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
