import { ZillowData, FloodData, ElevationData, GeocodeData } from '../types/property';

/**
 * Service for fetching property data from external sources via Supabase Edge Functions
 * Uses three free government APIs:
 * 1. Census Geocoding API - Convert address to coordinates
 * 2. FEMA NFHL API - Get flood zone and base flood elevation
 * 3. USGS Elevation API - Get ground elevation
 */

/**
 * Scrapes property data from Zillow
 * @param address - Street address of the property
 * @returns Promise with square footage and property cost
 */
export async function scrapeZillowData(address: string): Promise<ZillowData> {
  console.log('🏠 Zillow function called with address:', address);
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      console.error('Missing environment variables:', { supabaseUrl: !!supabaseUrl, supabaseKey: !!supabaseKey });
      return {
        square_footage: null,
        property_cost: null,
      };
    }

    const url = `${supabaseUrl}/functions/v1/scrape-zillow`;

    console.log('🏠 Calling Zillow Supabase Edge function:', url);
    console.log('🏠 Request payload:', { address });

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ address }),
    });

    console.log('🏠 Zillow response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('🏠 Zillow API error:', errorText);
      return {
        square_footage: null,
        property_cost: null,
      };
    }

    const data = await response.json();
    console.log('✅ Zillow raw response:', data);
    console.log('🏠 Square Footage from API:', data.square_footage);
    console.log('🏠 Property Cost from API:', data.property_cost);

    return {
      square_footage: data.square_footage || null,
      property_cost: data.property_cost || null,
    };
  } catch (error) {
    console.error('Error scraping Zillow data:', error);
    return {
      square_footage: null,
      property_cost: null,
    };
  }
}

/**
 * Fetches flood data from FEMA NFHL API
 * @param latitude - Property latitude coordinate
 * @param longitude - Property longitude coordinate
 * @returns Promise with base flood elevation and flood zone
 */
export async function scrapeFloodData(
  latitude: number,
  longitude: number
): Promise<FloodData> {
  console.log('🌊 FEMA function called with:', latitude, longitude);
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      console.error('Missing environment variables:', { supabaseUrl: !!supabaseUrl, supabaseKey: !!supabaseKey });
      return {
        base_flood_elevation: null,
        flood_zone: null,
      };
    }

    const url = `${supabaseUrl}/functions/v1/scrape-flood-data`;

    console.log('Calling flood data Supabase Edge function:', url);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ latitude, longitude }),
    });

    console.log('Flood data response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Flood API error:', errorText);
      return {
        base_flood_elevation: null,
        flood_zone: null,
      };
    }

    const data = await response.json();
    console.log('✅ FEMA raw response:', data);
    console.log('Base Flood Elevation from API:', data.base_flood_elevation);
    console.log('Flood Zone from API:', data.flood_zone);

    // Log debug info if available
    if (data.debug) {
      console.log('🔍 ==================== FEMA DEBUG INFO ====================');
      console.log('🔍 Layers tried:', data.debug.layers_tried);
      console.log('🔍 Layers with data:', data.debug.layers_with_data);
      console.log('🔍 BFE specific layer result:', data.debug.bfe_specific_layer_result);
      console.log('🔍 Available fields in response:', data.debug.available_fields);
      console.log('🔍 Number of fields:', data.debug.available_fields?.length || 0);

      if (data.debug.available_fields && data.debug.available_fields.length > 0) {
        console.log('🔍 ⚠️ FEMA HAS DATA! Field names returned:');
        data.debug.available_fields.forEach((field: string) => {
          console.log(`   ✓ ${field}`);
        });
      } else {
        console.log('🔍 ❌ No fields in response - location may not be in FEMA database');
      }

      console.log('🔍 Sample attributes from FEMA:');
      console.log('   - STATIC_BFE:', data.debug.sample_attributes?.STATIC_BFE);
      console.log('   - BFE_REVERT:', data.debug.sample_attributes?.BFE_REVERT);
      console.log('   - ELEV:', data.debug.sample_attributes?.ELEV);
      console.log('   - DEPTH:', data.debug.sample_attributes?.DEPTH);
      console.log('   - FLD_ZONE:', data.debug.sample_attributes?.FLD_ZONE);
      console.log('   - ZONE_SUBTY:', data.debug.sample_attributes?.ZONE_SUBTY);
      console.log('🔍 =========================================================');
    }

    return {
      base_flood_elevation: data.base_flood_elevation || null,
      flood_zone: data.flood_zone || null,
    };
  } catch (error) {
    console.error('Error scraping flood data:', error);
    return {
      base_flood_elevation: null,
      flood_zone: null,
    };
  }
}

/**
 * Fetches ground elevation from USGS Elevation API
 * @param latitude - Property latitude coordinate
 * @param longitude - Property longitude coordinate
 * @returns Promise with ground elevation in feet
 */
export async function getUSGSElevation(
  latitude: number,
  longitude: number
): Promise<ElevationData> {
  console.log('🏔️ USGS function called with:', latitude, longitude);
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      console.error('Missing environment variables:', { supabaseUrl: !!supabaseUrl, supabaseKey: !!supabaseKey });
      return {
        ground_elevation: null,
        data_source: null,
      };
    }

    const url = `${supabaseUrl}/functions/v1/get-usgs-elevation`;

    console.log('Calling USGS elevation Supabase Edge function:', url);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ latitude, longitude }),
    });

    console.log('USGS response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('USGS API error:', errorText);
      return {
        ground_elevation: null,
        data_source: null,
      };
    }

    const data = await response.json();
    console.log('✅ USGS raw response:', data);
    console.log('Ground Elevation from API:', data.ground_elevation);

    return {
      ground_elevation: data.ground_elevation || null,
      data_source: data.data_source || null,
    };
  } catch (error) {
    console.error('Error fetching elevation data:', error);
    return {
      ground_elevation: null,
      data_source: null,
    };
  }
}

/**
 * Geocodes an address to latitude/longitude using Census Geocoding API
 * @param address - Full street address
 * @returns Promise with latitude, longitude, and matched address
 */
export async function geocodeAddress(
  address: string
): Promise<GeocodeData | null> {
  console.log('📍 Geocoding address:', address);
  try {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseKey) {
      console.error('Missing environment variables:', { supabaseUrl: !!supabaseUrl, supabaseKey: !!supabaseKey });
      return null;
    }

    const url = `${supabaseUrl}/functions/v1/geocode-address`;

    console.log('Calling geocode Supabase Edge function:', url);

    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({ address }),
    });

    console.log('Geocode response status:', response.status);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Geocode API error:', errorText);
      return null;
    }

    const data = await response.json();
    console.log('✅ Geocode raw response:', data);
    console.log('Coordinates:', data.latitude, data.longitude);

    return {
      latitude: data.latitude,
      longitude: data.longitude,
      matched_address: data.matched_address,
    };
  } catch (error) {
    console.error('Error geocoding address:', error);
    return null;
  }
}
