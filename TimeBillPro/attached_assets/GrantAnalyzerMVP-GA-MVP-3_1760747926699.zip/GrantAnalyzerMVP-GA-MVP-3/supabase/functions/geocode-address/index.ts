import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { address } = await req.json();

    if (!address) {
      return new Response(
        JSON.stringify({ error: "Address is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    console.log(`📍 Geocoding address: ${address}`);

    const apiUrl = `https://geocoding.geo.census.gov/geocoder/locations/onelineaddress?address=${encodeURIComponent(address)}&benchmark=2020&format=json`;
    console.log('Census Geocoding API URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('Census Geocoding API Error Response:', errorBody);
      throw new Error(`Geocoding API error: ${response.status} - ${response.statusText}`);
    }

    const geocodeData = await response.json();
    console.log('Geocoding Response:', JSON.stringify(geocodeData, null, 2));

    if (geocodeData.result && geocodeData.result.addressMatches && geocodeData.result.addressMatches.length > 0) {
      const match = geocodeData.result.addressMatches[0];
      const coords = match.coordinates;
      
      console.log('✅ Address geocoded successfully');
      console.log('Coordinates:', coords.y, coords.x);
      console.log('Matched Address:', match.matchedAddress);

      return new Response(
        JSON.stringify({
          latitude: coords.y,
          longitude: coords.x,
          matched_address: match.matchedAddress,
        }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    } else {
      console.log('❌ Address not found');
      return new Response(
        JSON.stringify({
          error: "Address not found",
          message: "Could not geocode the provided address. Please check the address format and try again."
        }),
        {
          status: 404,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }
  } catch (error) {
    console.error("Error in geocode-address function:", error);

    return new Response(
      JSON.stringify({
        error: "Failed to geocode address",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});