import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { latitude, longitude } = await req.json();

    if (!latitude || !longitude) {
      return new Response(
        JSON.stringify({ error: "Latitude and longitude are required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    console.log(`🏔️ Fetching USGS Ground Elevation for: ${latitude}, ${longitude}`);

    const apiUrl = `https://epqs.nationalmap.gov/v1/json?x=${longitude}&y=${latitude}&units=Feet&output=json`;
    console.log('USGS API URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('USGS API Error Response:', errorBody);
      throw new Error(`USGS API error: ${response.status} - ${response.statusText}`);
    }

    const usgsData = await response.json();
    console.log('USGS Response:', JSON.stringify(usgsData, null, 2));

    let ground_elevation = null;
    let data_source = null;

    if (usgsData.value && usgsData.value !== -1000000) {
      ground_elevation = Math.round(usgsData.value * 10) / 10;
      data_source = usgsData.Data_Source || 'USGS National Elevation Dataset';
      console.log('✅ Ground Elevation found:', ground_elevation, 'ft');
    } else {
      console.log('ℹ️ No elevation data available for this location');
    }

    const data = {
      ground_elevation: ground_elevation,
      data_source: data_source,
    };

    return new Response(
      JSON.stringify(data),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in get-usgs-elevation function:", error);

    return new Response(
      JSON.stringify({
        error: "Failed to fetch elevation data",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});