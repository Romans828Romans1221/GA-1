import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

async function fetchFEMABFESpecific(latitude: number, longitude: number) {
  console.log('🎯 Querying FEMA Layer 1 specifically for BFE');

  try {
    const url = `https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer/1/query?geometry=${longitude},${latitude}&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects&outFields=*&returnGeometry=false&f=json`;

    console.log('🎯 BFE Layer URL:', url);

    const response = await fetch(url);
    const data = await response.json();

    console.log('🎯 BFE Layer 1 Response:', JSON.stringify(data, null, 2));

    if (data.features && data.features.length > 0) {
      console.log('✅ BFE Layer has features!');
      console.log('🎯 All attributes:', data.features[0].attributes);
      return data.features[0].attributes;
    } else {
      console.log('❌ No features in BFE layer');
      return null;
    }
  } catch (error) {
    console.error('❌ BFE Layer Error:', error);
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { latitude, longitude } = await req.json();

    if (!latitude || !longitude) {
      return new Response(
        JSON.stringify({ error: "Latitude and longitude are required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    console.log(`Fetching flood data for coordinates: ${latitude}, ${longitude}`);

    const bfeLayerData = await fetchFEMABFESpecific(latitude, longitude);
    console.log('🎯 BFE Layer Data:', bfeLayerData);

    const layers = [1, 2, 28, 0, 3, 4, 5];
    let femaData = null;
    let lastError = null;

    for (const layer of layers) {
      const apiUrl = `https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer/${layer}/query?geometry=${longitude},${latitude}&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects&outFields=*&returnGeometry=false&f=json`;
      console.log(`Trying FEMA layer ${layer}:`, apiUrl);

      try {
        const response = await fetch(apiUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (data.features && data.features.length > 0) {
            const attrs = data.features[0].attributes;
            console.log(`✅ Found data in layer ${layer}`);
            console.log('🔍 ALL FEMA ATTRIBUTES:', JSON.stringify(attrs, null, 2));
            console.log('🔍 Available field names:', Object.keys(attrs));
            console.log('🔍 STATIC_BFE value:', attrs.STATIC_BFE);
            console.log('🔍 BFE_REVERT value:', attrs.BFE_REVERT);
            console.log('🔍 ELEV value:', attrs.ELEV);
            console.log('🔍 DEPTH value:', attrs.DEPTH);
            console.log('🔍 FLD_ZONE value:', attrs.FLD_ZONE);
            console.log('🔍 ZONE_SUBTY value:', attrs.ZONE_SUBTY);
            femaData = data;
            break;
          } else {
            console.log(`Layer ${layer} returned no features`);
          }
        } else {
          console.log(`Layer ${layer} returned status ${response.status}`);
        }
      } catch (error) {
        lastError = error;
        console.log(`Layer ${layer} failed:`, error instanceof Error ? error.message : 'Unknown error');
      }
    }

    if (!femaData) {
      console.log('No FEMA data found in any layer, trying direct NFHL query...');

      const fallbackUrl = `https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer/identify?geometry=${longitude},${latitude}&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=1&mapExtent=${longitude-0.01},${latitude-0.01},${longitude+0.01},${latitude+0.01}&imageDisplay=400,400,96&returnGeometry=false&f=json`;
      console.log('Fallback URL:', fallbackUrl);

      const fallbackResponse = await fetch(fallbackUrl);
      if (fallbackResponse.ok) {
        const fallbackData = await fallbackResponse.json();
        if (fallbackData.results && fallbackData.results.length > 0) {
          femaData = { features: fallbackData.results.map((r: any) => ({ attributes: r.attributes })) };
        }
      }
    }

    if (!femaData || !femaData.features || femaData.features.length === 0) {
      console.log('No flood zone data found - likely Zone X (Minimal Risk)');
      return new Response(
        JSON.stringify({
          base_flood_elevation: null,
          flood_zone: 'Zone X (Minimal Risk)',
          debug: {
            layers_tried: layers.length,
            layers_with_data: 'none',
            bfe_specific_layer_result: bfeLayerData ? 'found' : 'none',
            available_fields: [],
            sample_attributes: {},
          },
        }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    console.log('Full FEMA API Response:', JSON.stringify(femaData, null, 2));

    let base_flood_elevation = null;
    let flood_zone = null;

    if (femaData.features && Array.isArray(femaData.features) && femaData.features.length > 0) {
      console.log(`Found ${femaData.features.length} features`);

      for (const feature of femaData.features) {
        const attributes = feature.attributes || {};
        console.log('Feature attributes:', JSON.stringify(attributes, null, 2));

        if (!flood_zone) {
          if (attributes.FLD_ZONE) {
            flood_zone = attributes.FLD_ZONE;
            console.log('Found FLD_ZONE:', flood_zone);
          } else if (attributes.ZONE_SUBTY) {
            flood_zone = attributes.ZONE_SUBTY;
            console.log('Found ZONE_SUBTY:', flood_zone);
          } else if (attributes.ZONE_LBL) {
            flood_zone = attributes.ZONE_LBL;
            console.log('Found ZONE_LBL:', flood_zone);
          }
        }

        if (!base_flood_elevation) {
          if (attributes.STATIC_BFE !== undefined && attributes.STATIC_BFE !== null) {
            base_flood_elevation = attributes.STATIC_BFE;
            console.log('Found STATIC_BFE:', base_flood_elevation);
          } else if (attributes.BFE_REVERT !== undefined && attributes.BFE_REVERT !== null) {
            base_flood_elevation = attributes.BFE_REVERT;
            console.log('Found BFE_REVERT:', base_flood_elevation);
          } else if (attributes.DEPTH !== undefined && attributes.DEPTH !== null) {
            base_flood_elevation = attributes.DEPTH;
            console.log('Found DEPTH:', base_flood_elevation);
          }
        }

        if (flood_zone && base_flood_elevation) {
          break;
        }
      }
    } else {
      console.log('No features found in response');
    }

    if (base_flood_elevation && typeof base_flood_elevation === 'string') {
      base_flood_elevation = parseFloat(base_flood_elevation);
    }

    if (base_flood_elevation !== null && (isNaN(base_flood_elevation) || base_flood_elevation === 0)) {
      base_flood_elevation = null;
    }

    console.log('Final Extracted - Flood Zone:', flood_zone, 'BFE:', base_flood_elevation);

    const firstFeatureAttrs = femaData?.features?.[0]?.attributes || {};
    const debugInfo = {
      layers_tried: layers.length,
      layers_with_data: femaData ? 'found' : 'none',
      bfe_specific_layer_result: bfeLayerData ? 'found' : 'none',
      available_fields: Object.keys(firstFeatureAttrs),
      sample_attributes: {
        STATIC_BFE: firstFeatureAttrs.STATIC_BFE,
        BFE_REVERT: firstFeatureAttrs.BFE_REVERT,
        ELEV: firstFeatureAttrs.ELEV,
        DEPTH: firstFeatureAttrs.DEPTH,
        FLD_ZONE: firstFeatureAttrs.FLD_ZONE,
        ZONE_SUBTY: firstFeatureAttrs.ZONE_SUBTY,
      },
    };

    const data = {
      base_flood_elevation: base_flood_elevation,
      flood_zone: flood_zone,
      debug: debugInfo,
    };

    return new Response(
      JSON.stringify(data),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in scrape-flood-data function:", error);

    return new Response(
      JSON.stringify({
        error: "Failed to fetch flood data",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});