import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { address } = await req.json();

    if (!address) {
      return new Response(
        JSON.stringify({ error: "Address is required" }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
        }
      );
    }

    console.log(`Fetching Zillow data for address: ${address}`);

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');

    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured.');
    }

    // Clean and format the address properly
    // RapidAPI expects format: "123 Main St, City, ST 12345"
    const cleanAddress = address.trim().replace(/\s+/g, ' ');
    console.log('Cleaned address:', cleanAddress);

    const apiUrl = `https://real-time-zillow-data.p.rapidapi.com/property-details-address?address=${encodeURIComponent(cleanAddress)}`;
    console.log('API URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'x-rapidapi-host': 'real-time-zillow-data.p.rapidapi.com',
        'x-rapidapi-key': rapidApiKey
      }
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('RapidAPI Error Response:', errorBody);

      // Check if it's an invalid address error
      if (response.status === 400 && errorBody.includes('Invalid address')) {
        console.log('Address not found in Zillow database');
        return new Response(
          JSON.stringify({
            square_footage: null,
            property_cost: null,
            error: 'ADDRESS_NOT_FOUND',
            message: 'This address was not found in Zillow\'s database. Try a different address or check the formatting.'
          }),
          {
            status: 200,
            headers: {
              ...corsHeaders,
              "Content-Type": "application/json",
            },
          }
        );
      }

      throw new Error(`RapidAPI error: ${response.status} - ${response.statusText}. Body: ${errorBody}`);
    }

    const zillowResponse = await response.json();

    console.log('Full RapidAPI Response:', JSON.stringify(zillowResponse, null, 2));

    let square_footage = null;
    let property_cost = null;

    // Extract square footage from livingAreaValue (as shown in screenshot)
    if (zillowResponse.data?.livingAreaValue) {
      square_footage = zillowResponse.data.livingAreaValue;
      console.log('Found livingAreaValue:', square_footage);
    }

    // Also try livingArea field
    if (!square_footage && zillowResponse.data?.livingArea) {
      square_footage = zillowResponse.data.livingArea;
      console.log('Found livingArea:', square_footage);
    }

    // Try propertyDetails array if exists
    if (!square_footage && Array.isArray(zillowResponse.data?.propertyDetails)) {
      for (const detail of zillowResponse.data.propertyDetails) {
        if (detail.livingAreaValue) {
          square_footage = detail.livingAreaValue;
          console.log('Found livingAreaValue in propertyDetails:', square_footage);
          break;
        }
        if (detail.livingArea) {
          square_footage = detail.livingArea;
          console.log('Found livingArea in propertyDetails:', square_footage);
          break;
        }
      }
    }

    // Try listingMetadata
    if (!square_footage && zillowResponse.data?.listingMetadata?.lotAreaValue) {
      square_footage = zillowResponse.data.listingMetadata.lotAreaValue;
      console.log('Found lotAreaValue from listingMetadata:', square_footage);
    }

    // Extract price from the data object (as shown in screenshot: price: 305000)
    if (zillowResponse.data?.price) {
      property_cost = zillowResponse.data.price;
      console.log('Found price:', property_cost);
    }

    // Try collections.modules[0].propertyDetails[0].price (from screenshot structure)
    if (!property_cost && zillowResponse.data?.collections?.modules?.[0]?.propertyDetails?.[0]?.price) {
      property_cost = zillowResponse.data.collections.modules[0].propertyDetails[0].price;
      console.log('Found price in collections.modules:', property_cost);
    }

    // If not found, try zestimate
    if (!property_cost && zillowResponse.data?.zestimate) {
      property_cost = zillowResponse.data.zestimate;
      console.log('Found zestimate:', property_cost);
    }

    console.log('Final Extracted - Square Footage:', square_footage, 'Price:', property_cost);

    const data = {
      square_footage: square_footage,
      property_cost: property_cost,
    };

    return new Response(
      JSON.stringify(data),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in scrape-zillow function:", error);

    return new Response(
      JSON.stringify({
        error: "Failed to fetch Zillow data",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});