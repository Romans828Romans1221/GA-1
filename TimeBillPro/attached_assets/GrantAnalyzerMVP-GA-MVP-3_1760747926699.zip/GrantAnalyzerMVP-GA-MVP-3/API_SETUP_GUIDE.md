# Property Analyzer - API Setup Guide

This guide will walk you through setting up the APIs needed for your Property Elevation Analyzer tool.

---

## 🏠 ZILLOW API SETUP (via RapidAPI)

### Step 1: Create RapidAPI Account

1. Go to **https://rapidapi.com/**
2. Click the **"Sign Up"** button in the top right corner
3. Sign up using one of these options:
   - Email and password
   - Google account
   - GitHub account
4. Verify your email address (check your inbox for verification email)

---

### Step 2: Subscribe to Zillow API

1. Visit the Zillow API page: **https://rapidapi.com/apimaker/api/zillow-com1**
2. You'll see the API page with:
   - API description
   - Code examples
   - Pricing tiers
3. Click on the **"Pricing"** tab
4. You'll see different subscription tiers:
   - **Basic (FREE)**: 100 requests per month
   - **Pro**: More requests (paid)
   - **Ultra/Mega**: High volume (paid)
5. Click **"Subscribe to Test"** button under the Basic (Free) plan
6. Follow the prompts to complete the subscription

---

### Step 3: Get Your RapidAPI Key

1. After subscribing, you'll be on the Zillow API page
2. Look at the **right side** of the page for the **"Code Snippets"** section
3. In the code example, find the line that says:
   ```
   'X-RapidAPI-Key': 'abc123def456...'
   ```
4. **Copy the entire key** (it's a long string of letters and numbers)
5. Keep this key safe - you'll need it in the next step!

**Example of what the key looks like:**
```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0
```

---

### Step 4: Add API Key to Supabase

1. Go to your **Supabase Dashboard**: https://supabase.com/dashboard
2. Click on **your project** (the one for this Property Analyzer)
3. In the left sidebar, click **"Edge Functions"**
4. Look for a **"Secrets"** or **"Manage secrets"** button/tab and click it
5. Click **"Add new secret"** or **"New secret"**
6. Fill in the form:
   - **Name**: `RAPIDAPI_KEY`
   - **Value**: (paste your RapidAPI key here)
7. Click **"Save"** or **"Create"**

**IMPORTANT:** The name must be exactly `RAPIDAPI_KEY` (all uppercase, no spaces)

---

### Step 5: Test the Zillow API

Once you've added your API key to Supabase, the Zillow scraper will automatically work!

**To test it:**
1. Open your Property Analyzer application
2. Enter a property address (example: "123 Main St, New York, NY")
3. Enter coordinates for the property
4. Click **"Analyze Property"**
5. The app will fetch square footage and property cost from Zillow

**If you see errors:**
- Check that your RapidAPI key is correct in Supabase
- Make sure you're subscribed to the Zillow API on RapidAPI
- Check the browser console (F12) for error messages

---

## 💧 FLOOD DATA SETUP

Good news! The flood data scraper is **already set up and working** using the free FEMA API.

**No additional setup needed!** The flood data will automatically be retrieved when you analyze a property.

### How it works:
1. Uses the free FEMA Flood Map Service
2. No API key required
3. Queries based on latitude/longitude coordinates
4. Returns:
   - Base Flood Elevation (BFE)
   - Flood Zone (A, AE, X, etc.)

---

## 🔧 TROUBLESHOOTING

### Issue: "RAPIDAPI_KEY not configured" error

**Solution:**
1. Make sure you added the API key in Supabase Dashboard
2. Verify the secret name is exactly: `RAPIDAPI_KEY`
3. Try redeploying the Edge Function

---

### Issue: Zillow API returns no data

**Possible causes:**
1. **Address format:** Try different address formats:
   - "123 Main St, New York, NY 10001"
   - "123 Main Street, New York, New York"
   - Just "123 Main St New York NY"
2. **API rate limit:** Free plan has 100 requests/month
3. **Property not found:** The property might not be in Zillow's database

---

### Issue: Flood data not showing

**Possible causes:**
1. **Coordinates:** Make sure latitude/longitude are accurate
2. **Area not mapped:** Some areas might not have FEMA flood data
3. **FEMA API down:** Check https://hazards.fema.gov/gis/ to verify service status

---

## 📝 SUMMARY CHECKLIST

Before using the Property Analyzer, make sure you've completed:

- [ ] Created RapidAPI account
- [ ] Subscribed to Zillow API on RapidAPI (free plan)
- [ ] Copied your RapidAPI key
- [ ] Added RAPIDAPI_KEY secret in Supabase Dashboard
- [ ] Tested the application with a real property address

---

## 💡 USAGE TIPS

**For best results:**

1. **Address Format:**
   - Include street number and name
   - Include city and state
   - ZIP code is optional but helpful
   - Example: "1600 Pennsylvania Avenue NW, Washington, DC"

2. **Coordinates:**
   - Use Google Maps to get accurate coordinates
   - Right-click on the property location
   - Click "What's here?"
   - Copy the latitude and longitude values

3. **Understanding Results:**
   - **Square Footage:** Total living area
   - **Property Cost:** Zillow's estimated value (Zestimate)
   - **Base Flood Elevation:** Height (in feet) that floodwater is expected to reach
   - **Flood Zone:** FEMA designation (AE = high risk with elevation, X = low risk)

---

## 🆘 NEED MORE HELP?

**RapidAPI Support:**
- Visit: https://docs.rapidapi.com/docs/consumer-quick-start-guide
- Contact: support@rapidapi.com

**FEMA Flood Maps:**
- Visit: https://www.fema.gov/flood-maps
- Flood Map Service Center: https://msc.fema.gov/

**Supabase Support:**
- Documentation: https://supabase.com/docs
- Community: https://github.com/supabase/supabase/discussions

---

## 🎉 YOU'RE ALL SET!

Once you've completed the steps above, your Property Elevation Analyzer is ready to use!

Start analyzing properties by entering an address and coordinates, then click "Analyze Property" to see the results.
