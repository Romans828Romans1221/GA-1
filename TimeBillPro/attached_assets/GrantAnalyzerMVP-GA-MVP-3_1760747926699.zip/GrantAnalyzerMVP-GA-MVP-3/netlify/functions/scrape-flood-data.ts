import { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: "",
    };
  }

  try {
    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Request body is required" }),
      };
    }

    const { latitude, longitude } = JSON.parse(event.body);

    if (!latitude || !longitude) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Latitude and longitude are required" }),
      };
    }

    console.log(`Fetching flood data for coordinates: ${latitude}, ${longitude}`);

    const tolerance = 100;
    const mapExtent = `${longitude - 0.01},${latitude - 0.01},${longitude + 0.01},${latitude + 0.01}`;

    const femaUrl = new URL('https://hazards.fema.gov/gis/nfhl/rest/services/public/NFHL/MapServer/identify');
    femaUrl.searchParams.append('geometry', JSON.stringify({ x: longitude, y: latitude }));
    femaUrl.searchParams.append('geometryType', 'esriGeometryPoint');
    femaUrl.searchParams.append('layers', 'all:28');
    femaUrl.searchParams.append('mapExtent', mapExtent);
    femaUrl.searchParams.append('imageDisplay', '400,400,96');
    femaUrl.searchParams.append('returnGeometry', 'false');
    femaUrl.searchParams.append('tolerance', tolerance.toString());
    femaUrl.searchParams.append('f', 'json');

    const response = await fetch(femaUrl.toString(), {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      }
    });

    if (!response.ok) {
      throw new Error(`FEMA API error: ${response.status} - ${response.statusText}`);
    }

    const femaData = await response.json();

    let base_flood_elevation = null;
    let flood_zone = null;

    if (femaData.results && femaData.results.length > 0) {
      for (const result of femaData.results) {
        const attributes = result.attributes || {};

        if (!flood_zone) {
          flood_zone = attributes.FLD_ZONE ||
                      attributes.ZONE_SUBTY ||
                      attributes.ZONE_LBL ||
                      null;
        }

        if (!base_flood_elevation) {
          base_flood_elevation = attributes.STATIC_BFE ||
                                attributes.BFE_REVERT ||
                                attributes.DEPTH ||
                                null;

          if (base_flood_elevation && typeof base_flood_elevation === 'string') {
            base_flood_elevation = parseFloat(base_flood_elevation);
          }

          if (base_flood_elevation === 0 || isNaN(base_flood_elevation)) {
            base_flood_elevation = null;
          }
        }

        if (flood_zone && base_flood_elevation) {
          break;
        }
      }
    }

    console.log('Extracted - Flood Zone:', flood_zone, 'BFE:', base_flood_elevation);

    const data = {
      base_flood_elevation: base_flood_elevation,
      flood_zone: flood_zone,
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(data),
    };
  } catch (error) {
    console.error("Error in scrape-flood-data function:", error);

    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to fetch flood data",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
    };
  }
};

export { handler };
