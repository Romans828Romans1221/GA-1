import { Handler, HandlerEvent, HandlerContext } from "@netlify/functions";

const handler: Handler = async (event: HandlerEvent, context: HandlerContext) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: "",
    };
  }

  try {
    if (!event.body) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Request body is required" }),
      };
    }

    const { address } = JSON.parse(event.body);

    if (!address) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Address is required" }),
      };
    }

    console.log(`Fetching Zillow data for address: ${address}`);

    const rapidApiKey = process.env.RAPIDAPI_KEY || '4cc7c643famsh9fa744b32bcbfdp10d03cjsn2d9d84a3b502';

    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured.');
    }

    const apiUrl = `https://real-time-zillow-data.p.rapidapi.com/property-details-address?address=${encodeURIComponent(address)}`;
    console.log('API URL:', apiUrl);

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'x-rapidapi-host': 'real-time-zillow-data.p.rapidapi.com',
        'x-rapidapi-key': rapidApiKey
      }
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error('RapidAPI Error Response:', errorBody);
      throw new Error(`RapidAPI error: ${response.status} - ${response.statusText}. Body: ${errorBody}`);
    }

    const zillowResponse = await response.json();

    let square_footage = null;
    let property_cost = null;

    if (zillowResponse.data?.livingArea) {
      square_footage = zillowResponse.data.livingArea;
    } else if (zillowResponse.data?.livingAreaValue) {
      square_footage = zillowResponse.data.livingAreaValue;
    }

    if (zillowResponse.data?.price) {
      property_cost = zillowResponse.data.price;
    } else if (zillowResponse.data?.zestimate) {
      property_cost = zillowResponse.data.zestimate;
    } else if (zillowResponse.price) {
      property_cost = zillowResponse.price;
    }

    console.log('RapidAPI Response:', JSON.stringify(zillowResponse, null, 2));
    console.log('Extracted - Square Footage:', square_footage, 'Price:', property_cost);

    const data = {
      square_footage: square_footage,
      property_cost: property_cost,
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(data),
    };
  } catch (error) {
    console.error("Error in scrape-zillow function:", error);

    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to fetch Zillow data",
        details: error instanceof Error ? error.message : "Unknown error"
      }),
    };
  }
};

export { handler };
